<?php
// Copy this file to local.php only for local development. In Staging or
// Production prefer DB_* and APP_* environment variables so credentials and
// domains remain outside the deployed codebase.
return [
    'db' => [
        'driver' => 'mysql',
        'host' => 'localhost',
        'port' => 3306,
        'database' => 'YOUR_DATABASE',
        'username' => 'YOUR_USERNAME',
        'password' => 'YOUR_PASSWORD',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'base_url' => 'https://your-domain.example',
        'debug' => false,
    ],
];
