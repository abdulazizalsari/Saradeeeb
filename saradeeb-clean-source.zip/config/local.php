<?php

return [
    'db' => [
        'driver' => 'mysql',
        'host' => 'localhost',
        'port' => 3307,
        'database' => 'saradeeeb_local',
        'username' => 'saradeeeb',
        'password' => 'SaradeeebLocal2026!',
        'charset' => 'utf8mb4',
    ],

    'app' => [
        'base_url' => 'http://localhost:8000',
        'debug' => true,
    ],
];
