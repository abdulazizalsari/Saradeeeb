<?php $A=auth_ui($locale); ?>
<section class="auth-section auth-section-premium">
    <div class="auth-shell">
        <div class="auth-visual" aria-hidden="true">
            <div class="auth-visual-brand"><span><?=$locale==='ar'?'س':'S'?></span><strong><?=e($A['brand'])?></strong></div>
            <div class="auth-visual-copy">
                <span class="eyebrow">SARAD͟EEB CMS</span>
                <h2><?=e($A['login_visual_title'])?></h2>
                <p><?=e($A['login_visual_text'])?></p>
            </div>
            <div class="auth-visual-lines"><i></i><i></i><i></i></div>
        </div>

        <div class="auth-card auth-card-premium">
            <a class="auth-back-link" href="<?=e(locale_url($locale))?>">← <?=e($A['back_site'])?></a>
            <span class="eyebrow"><?= e(tr('welcome_back', $locale)) ?></span>
            <h1><?= e(tr('login', $locale)) ?></h1>
            <p><?= e(tr('login_desc', $locale)) ?></p>

            <?php if ($x = flash('success')): ?><div class="notice success"><?= e($x) ?></div><?php endif; ?>
            <?php if ($x = flash('error')): ?><div class="notice error"><?= e($x) ?></div><?php endif; ?>

            <form method="post" action="<?=e(locale_url($locale,'login'))?>" class="form-stack auth-form-premium">
                <?= csrf_field() ?>
                <label>
                    <span><?= e(tr('email', $locale)) ?></span>
                    <div class="input-with-icon"><i aria-hidden="true">@</i><input type="email" name="email" value="<?= old('email') ?>" required autocomplete="email" placeholder="name@example.com"></div>
                </label>
                <label>
                    <span><?= e(tr('password', $locale)) ?></span>
                    <div class="input-with-icon"><i aria-hidden="true">••</i><input type="password" name="password" required autocomplete="current-password" placeholder="••••••••••••"></div>
                </label>
                <button class="btn btn-primary btn-full auth-submit" type="submit"><?= e(tr('enter', $locale)) ?> <span>←</span></button>
            </form>
            <div class="auth-forgot"><a href="<?=e(locale_url($locale,'forgot-password'))?>"><?=e($A['forgot'])?></a></div>

            <div class="auth-foot"><?= e(tr('no_account', $locale)) ?> <a href="<?=e(locale_url($locale,'register'))?>"><?=e($A['create_account'])?></a> · <a href="<?=e(locale_url($locale,'writer-application'))?>"><?= e(tr('join_writer', $locale)) ?></a></div>
            <div class="auth-security-note"><span>●</span> <?=e($A['secure'])?> · <?=e($A['session'])?></div>
        </div>
    </div>
</section>
