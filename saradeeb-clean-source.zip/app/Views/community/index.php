<?php
$canonical=locale_url($locale,'community');
$headExtra='<meta property="og:type" content="website"><meta property="og:title" content="'.e($title).'"><meta property="og:description" content="'.e($description).'">';
$C=community_ui($locale);
?>
<section class="community-page community-home">
  <div class="container community-hero">
    <div><span class="community-eyebrow"><?=e($C['brand'])?></span><h1><?=e($C['hero'])?></h1><p><?=e($description)?></p></div>
    <div class="community-hero-actions"><?php if($user):?><a class="btn btn-primary" href="<?=e(locale_url($locale,'community/new'))?>">+ <?=e($C['start'])?></a><?php else:?><a class="btn btn-primary" href="<?=e(locale_url($locale,'register'))?>"><?=e($C['register'])?></a><a class="btn btn-ghost" href="<?=e(locale_url($locale,'login'))?>"><?=e($C['login'])?></a><?php endif;?></div>
  </div>

  <div class="container community-toolbar">
    <nav class="community-filters" aria-label="<?=e($C['filter_label'])?>">
      <?php $filters=['latest'=>$C['latest'],'discussed'=>$C['discussed'],'views'=>$C['views_filter'],'unanswered'=>$C['unanswered'],'active'=>$C['active'],'following'=>$C['following']]; foreach($filters as $key=>$label): if($key==='following'&&!$user)continue;?><a class="<?=$filter===$key?'active':''?>" href="<?=e(locale_url($locale,'community').'?filter='.$key)?>"><?=e($label)?></a><?php endforeach;?>
    </nav>
    <form class="community-search" action="<?=e(locale_url($locale,'community'))?>"><input name="q" value="<?=e($q)?>" placeholder="<?=e($C['search'])?>"><button aria-label="<?=e(tr('search',$locale))?>"><?=navigation_icon_svg('search')?></button></form>
  </div>

  <?php if($week):?><div class="container"><section class="community-week-card"><div><span>✦ <?=e($C['week'])?></span><h2><a href="<?=e(locale_url($locale,'community/topic/'.$week['slug']))?>"><?=e($week['title'])?></a></h2><p><?=e($week['author_name'])?> · <?=e($week['category_name']??$C['brand'])?> · <?=number_format((int)$week['replies_count'])?> <?=e($C['reply'])?></p></div><a class="btn btn-ghost" href="<?=e(locale_url($locale,'community/topic/'.$week['slug']))?>"><?=e($C['enter'])?></a></section></div><?php endif;?>

  <?php if($categories):?><section class="container community-categories"><div class="community-section-head"><div><span><?=e($C['sections'])?></span><h2><?=e($C['choose'])?></h2></div></div><div class="community-category-grid"><?php foreach($categories as $cat):?><a href="<?=e(locale_url($locale,'community/'.$cat['slug']))?>"><strong><?=e($cat['name'])?></strong><p><?=e($cat['description'])?></p><span><?=number_format((int)$cat['topic_count'])?> <?=e($C['discussion_count'])?></span></a><?php endforeach;?></div></section><?php endif;?>

  <section class="container community-stream">
    <div class="community-section-head"><div><span><?=e($C['discussions'])?></span><h2><?=e($q!==''?$C['results']:$C['now'])?></h2></div><?php if($user):?><div class="community-account-links"><a href="<?=e(locale_url($locale,'community/saved'))?>"><?=e($C['saved'])?></a><a href="<?=e(locale_url($locale,'community/notifications'))?>"><?=e($C['notifications'])?></a></div><?php endif;?></div>
    <div class="community-topic-list"><?php if(!$rows):?><div class="community-empty"><strong><?=e($C['empty'])?></strong><p><?=e($C['empty_text'])?></p></div><?php else: foreach($rows as $topic) require __DIR__.'/_topic-card.php'; endif;?></div>
    <?=community_pagination($pagination,locale_url($locale,'community'),['filter'=>$filter,'q'=>$q])?>
  </section>
</section>
