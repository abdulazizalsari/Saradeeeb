<?php
$canonical=!empty($page['canonical_url'])?$page['canonical_url']:locale_url($locale,'page/'.$page['slug']);
ob_start();
foreach($translations as $t):?><link rel="alternate" hreflang="<?=e($t['locale'])?>" href="<?=e(locale_url($t['locale'],'page/'.$t['slug']))?>"><?php endforeach;
if(($page['content_mode']??'visual')==='html' && !empty($page['custom_css'])):?><style><?= $page['custom_css'] ?></style><?php endif;
$headExtra=ob_get_clean();
$template=$page['template']??'standard';
$bg=preg_match('/^#[0-9a-f]{6}$/i',(string)($page['page_bg_color']??''))?$page['page_bg_color']:'#ffffff';
$text=preg_match('/^#[0-9a-f]{6}$/i',(string)($page['page_text_color']??''))?$page['page_text_color']:'#202522';
$width=in_array($page['content_width']??'standard',['narrow','standard','wide','full'],true)?$page['content_width']:'standard';
$widthClass='page-content-width-'.$width;
?>
<?php if($template!=='landing' && ($page['show_title']??1)):?><section class="page-hero" style="background:<?=e($bg)?>;color:<?=e($text)?>"><div class="container"><span class="eyebrow">سراديب</span><h1><?=e($page['title'])?></h1><?php if(!empty($page['featured_image'])):?><img class="page-featured-image" src="<?=e($page['featured_image'])?>" alt="<?=e($page['title'])?>"><?php endif;?></div></section><?php endif;?>
<section class="section page-template-<?=e($template)?> page-custom-appearance" style="background:<?=e($bg)?>;color:<?=e($text)?>"><div class="<?=e($widthClass)?> article-content standalone-page"><?=$page['content']?></div></section>
<?php if(($page['content_mode']??'visual')==='html' && !empty($page['custom_js'])):?><script><?= $page['custom_js'] ?></script><?php endif;?>
