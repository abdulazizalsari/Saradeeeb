<?php
$copy=[
'ar'=>['name'=>'الاسم','email'=>'البريد الإلكتروني','subject'=>'الموضوع','message'=>'الرسالة','send'=>'إرسال الرسالة','privacy'=>'سيتم حفظ الرسالة لدى الإدارة للمتابعة.'],
'en'=>['name'=>'Name','email'=>'Email','subject'=>'Subject','message'=>'Message','send'=>'Send message','privacy'=>'A copy of your message is stored for the admin team to follow up.'],
'es'=>['name'=>'Nombre','email'=>'Correo electrónico','subject'=>'Asunto','message'=>'Mensaje','send'=>'Enviar mensaje','privacy'=>'Se guardará una copia del mensaje para que el equipo pueda darle seguimiento.'],
'fr'=>['name'=>'Nom','email'=>'E-mail','subject'=>'Objet','message'=>'Message','send'=>'Envoyer le message','privacy'=>'Une copie du message est conservée afin que l’équipe puisse assurer le suivi.'],
'ru'=>['name'=>'Имя','email'=>'Эл. почта','subject'=>'Тема','message'=>'Сообщение','send'=>'Отправить сообщение','privacy'=>'Копия сообщения сохраняется для дальнейшей обработки командой.'],
][$locale]??['name'=>'Name','email'=>'Email','subject'=>'Subject','message'=>'Message','send'=>'Send message','privacy'=>''];
foreach($copy as $k=>$fallback) $copy[$k]=translation_text('contact',$k,$locale,(string)$fallback);
$labels['title']=translation_text('contact','title',$locale,(string)($labels['title']??'Contact'));
$labels['desc']=translation_text('contact','desc',$locale,(string)($labels['desc']??''));
?>
<section class="page-hero"><div class="container"><span class="eyebrow">Saradeeeb</span><h1><?=e($labels['title']??'Contact')?></h1><p><?=e($labels['desc']??'')?></p></div></section>
<section class="section"><div class="container"><div class="panel public-form-card"><form method="post" action="<?=e(locale_url($locale,'contact'))?>" class="form-grid"><?=csrf_field()?><input type="text" name="website" value="" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true"><label><?=e($copy['name'])?><input name="name" value="<?=old('name')?>" required maxlength="160"></label><label><?=e($copy['email'])?><input type="email" name="email" value="<?=old('email')?>" required maxlength="190"></label><label class="span-2"><?=e($copy['subject'])?><input name="subject" value="<?=old('subject')?>" maxlength="220"></label><label class="span-2"><?=e($copy['message'])?><textarea name="message" rows="9" required minlength="10" maxlength="20000"><?=old('message')?></textarea></label><div class="span-2"><p class="settings-help"><?=e($copy['privacy'])?></p><button class="btn btn-primary" type="submit"><?=e($copy['send'])?></button></div></form></div></div></section>
