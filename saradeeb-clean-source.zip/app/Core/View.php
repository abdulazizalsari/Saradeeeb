<?php
namespace App\Core;
final class View {
    public static function render(string $view, array $data=[], string $layout='public'): void {
        $viewPath=BASE_PATH.'/app/Views/'.$view.'.php';
        if(!is_file($viewPath)) throw new \RuntimeException('View not found: '.$view);
        extract($data, EXTR_SKIP);
        ob_start(); require $viewPath; $content=ob_get_clean();
        $layoutPath=BASE_PATH.'/app/Views/layouts/'.$layout.'.php';
        if(is_file($layoutPath)) require $layoutPath; else echo $content;
    }
}
