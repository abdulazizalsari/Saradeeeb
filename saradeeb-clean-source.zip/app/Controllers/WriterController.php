<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\Upload;
use App\Core\View;

final class WriterController {
    private function guard(): array {
        Auth::requireRole(['admin','editor','writer','trusted_writer']);
        $u = Auth::user();
        if (($u['status'] ?? '') !== 'active') {
            http_response_code(403);
            exit('الحساب غير مفعل.');
        }
        return $u;
    }

    public function dashboard(): void {
        $u = $this->guard();
        $default=default_locale();
        $articles = Database::all(
            "SELECT a.*, (SELECT title FROM article_translations t WHERE t.article_id=a.id ORDER BY (t.locale=?) DESC, t.id LIMIT 1) title
             FROM articles a WHERE author_id=? ORDER BY updated_at DESC",
            [$default,$u['id']]
        );
        $notifications = [];
        try {
            $notifications = Database::all(
                "SELECT * FROM notifications WHERE user_id=? ORDER BY is_read ASC, created_at DESC LIMIT 20",
                [$u['id']]
            );
        } catch (\Throwable) {}
        View::render('writer/dashboard', compact('u','articles','notifications') + ['title'=>'لوحة الكاتب'], 'dashboard');
    }

    public function edit(?string $id=null): void {
        $u = $this->guard();
        $article = null;
        $translations = [];

        if ($id) {
            $article = Database::one('SELECT * FROM articles WHERE id=?', [(int)$id]);
            if (!$article || (!is_editor() && (int)$article['author_id'] !== (int)$u['id'])) {
                http_response_code(403);
                exit('غير مصرح.');
            }
            $translations = Database::all('SELECT * FROM article_translations WHERE article_id=?', [(int)$id]);
        }

        $byLocale = [];
        foreach ($translations as $t) $byLocale[$t['locale']] = $t;

        $categories = Database::all(
            "SELECT c.id,c.sort_order,ct.locale,ct.name,ct.slug
             FROM categories c
             LEFT JOIN category_translations ct ON ct.category_id=c.id
             ORDER BY c.sort_order,c.id,ct.locale"
        );
        $categoryMatrix = [];
        foreach ($categories as $row) {
            $cid = (int)$row['id'];
            $categoryMatrix[$cid] ??= ['id'=>$cid,'sort_order'=>(int)$row['sort_order'],'translations'=>[]];
            if (!empty($row['locale'])) {
                $categoryMatrix[$cid]['translations'][$row['locale']] = [
                    'name'=>$row['name'],
                    'slug'=>$row['slug'],
                ];
            }
        }
        uasort($categoryMatrix, static fn($a,$b) => $a['sort_order'] <=> $b['sort_order']);

        $mediaLibrary=[]; if(is_editor()){ try{$mediaLibrary=Database::all('SELECT id,path,title,alt_text,original_name,width,height FROM media ORDER BY id DESC LIMIT 120');}catch(\Throwable){} }
        View::render(
            'writer/editor',
            compact('u','article','byLocale','categoryMatrix','mediaLibrary') + ['title'=>$article?'تحرير المقال':'مقال جديد'],
            'dashboard'
        );
    }


    public function preview(string $id, string $locale): void {
        $u = $this->guard();
        if (!valid_locale($locale)) { http_response_code(404); exit('Language not found'); }
        $article = Database::one(
            "SELECT a.*,t.title,t.slug,t.excerpt,t.content,t.seo_title,t.seo_description,t.seo_keywords,t.hashtags,t.og_image,
                    u.name author_name,u.username,u.bio author_bio,u.avatar author_avatar,
                    c.id category_id,ct.name category_name,ct.slug category_slug
             FROM articles a
             JOIN article_translations t ON t.article_id=a.id AND t.locale=?
             JOIN users u ON u.id=a.author_id
             LEFT JOIN categories c ON c.id=a.category_id
             LEFT JOIN category_translations ct ON ct.category_id=c.id AND ct.locale=?
             WHERE a.id=? LIMIT 1",
            [$locale,$locale,(int)$id]
        );
        if (!$article || (!is_editor() && (int)$article['author_id'] !== (int)$u['id'])) {
            http_response_code(403); exit('غير مصرح.');
        }
        $translations = [['locale'=>$locale,'title'=>$article['title'],'slug'=>$article['slug']]];
        $related = [];
        $title = '[معاينة] '.$article['title'];
        $description = $article['excerpt'];
        View::render('public/article', compact('locale','article','translations','related','title','description'), 'public');
    }

    public function save(): void { $this->persist(false); }
    public function submit(): void { $this->persist(true); }

    private function normalizeHashtags(string $value): string {
        $value = str_replace(["\r","\n",'،',';'], ',', $value);
        $parts = preg_split('/[\s,]+/u', $value, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $out = [];
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part === '') continue;
            $part = ltrim($part, '#');
            $part = preg_replace('/[^\p{L}\p{N}_\-]+/u', '', $part) ?? '';
            if ($part === '') continue;
            $tag = '#'.$part;
            if (!in_array($tag, $out, true)) $out[] = $tag;
            if (count($out) >= 20) break;
        }
        return implode(' ', $out);
    }

    private function persist(bool $submit): void {
        $u = $this->guard();
        Csrf::enforce();
        $id = (int)($_POST['article_id'] ?? 0);
        $article = null;

        if ($id) {
            $article = Database::one('SELECT * FROM articles WHERE id=?', [$id]);
            if (!$article || (!is_editor() && (int)$article['author_id'] !== (int)$u['id'])) {
                http_response_code(403);
                exit('غير مصرح.');
            }
        }

        // One category belongs to the article itself. Every translation inherits the same category ID.
        $category = (int)($_POST['category_id'] ?? 0) ?: null;
        $featured = null;
        try {
            $featured = Upload::image($_FILES['featured_image'] ?? []);
            // Editors can reuse a file already stored in the managed media library instead of re-uploading it.
            if (!$featured) {
                $existingMediaPath = trim((string)($_POST['featured_image_existing'] ?? ''));
                if ($existingMediaPath !== '') {
                    $media = Database::one('SELECT path FROM media WHERE path=? LIMIT 1', [$existingMediaPath]);
                    if ($media) $featured = (string)$media['path'];
                }
            }
        } catch (\Throwable $e) {
            flash('error', $e->getMessage());
            redirect($id ? '/writer/articles/'.$id : '/writer/articles/new');
        }

        if ($submit) {
            $status = is_editor() ? 'published' : 'review';
        } else {
            $status = (is_editor() && $article) ? (string)$article['status'] : 'draft';
        }
        $publishedAt = $status === 'published' ? date('Y-m-d H:i:s') : null;

        // A translation has a publication lifecycle of its own.  Keep any
        // incomplete translation as a draft, but report that fact to the
        // editor rather than returning a misleading "saved/published" result.
        $translationIssues = [];
        Database::transaction(function() use (&$id,$u,$category,$featured,$status,$publishedAt,$article,&$translationIssues) {
            if (!$id) {
                $id = Database::insert(
                    'INSERT INTO articles(author_id,category_id,status,is_featured,featured_image,published_at) VALUES(?,?,?,?,?,?)',
                    [$u['id'],$category,$status,0,$featured,$publishedAt]
                );
            } else {
                Database::exec(
                    'UPDATE articles SET category_id=?,status=?,featured_image=COALESCE(?,featured_image),published_at=CASE WHEN ?="published" THEN COALESCE(published_at,?) ELSE published_at END,updated_at=CURRENT_TIMESTAMP WHERE id=?',
                    [$category,$status,$featured,$status,$publishedAt,$id]
                );
            }

            foreach (enabled_locales() as $locale=>$info) {
                $title = trim((string)($_POST['title'][$locale] ?? ''));
                $content = trim((string)($_POST['content'][$locale] ?? ''));
                $existing = Database::one('SELECT * FROM article_translations WHERE article_id=? AND locale=?', [$id,$locale]);
                if ($title === '' && $content === '') {
                    // Empty editor fields never delete a saved translation implicitly.
                    continue;
                }

                $slug = slugify((string)($_POST['slug'][$locale] ?? $title));
                $excerpt = trim((string)($_POST['excerpt'][$locale] ?? ''));
                if ($excerpt === '') $excerpt = mb_substr(trim(strip_tags($content)), 0, 240);
                $seoTitle = trim((string)($_POST['seo_title'][$locale] ?? ''));
                $seoDesc = trim((string)($_POST['seo_description'][$locale] ?? ''));
                $seoKeywords = trim((string)($_POST['seo_keywords'][$locale] ?? ''));
                $hashtags = $this->normalizeHashtags((string)($_POST['hashtags'][$locale] ?? ''));
                $imageAlt = mb_substr(trim((string)($_POST['image_alt'][$locale] ?? '')),0,255);
                $imageCaption = mb_substr(trim((string)($_POST['image_caption'][$locale] ?? '')),0,500);
                $ogTitle = mb_substr(trim((string)($_POST['og_title'][$locale] ?? $seoTitle)),0,255);
                $ogDescription = mb_substr(trim((string)($_POST['og_description'][$locale] ?? $seoDesc)),0,320);
                $clean = sanitize_html($content);

                $requestedStatus=(string)($_POST['translation_status'][$locale]??'');
                $translationStatus=is_editor() && $status==='published' && in_array($requestedStatus,['draft','published'],true)?$requestedStatus:(($status === 'published' && is_editor())?'published':'draft');
                $reviewState=is_editor()?((string)($_POST['review_state'][$locale]??($translationStatus==='published'?'approved':'draft'))):($submit?'review':'draft');
                if(!in_array($reviewState,['draft','review','approved'],true)) $reviewState='draft';
                // A translation is never marked public until its required public
                // fields exist.  The list/detail queries enforce the same rule.
                $completeForPublishing=$title!=='' && $slug!=='' && trim(strip_tags($clean))!=='';
                if($translationStatus==='published' && !$completeForPublishing){
                    $translationStatus='draft';
                    $reviewState='draft';
                    $translationIssues[] = strtoupper($locale);
                } elseif($translationStatus==='published') {
                    $reviewState='approved';
                }

                if ($existing) {
                    $before = $existing;
                    $changed =
                        (string)($before['title'] ?? '') !== $title ||
                        (string)($before['slug'] ?? '') !== $slug ||
                        (string)($before['excerpt'] ?? '') !== $excerpt ||
                        (string)($before['content'] ?? '') !== $clean ||
                        (string)($before['seo_title'] ?? '') !== $seoTitle ||
                        (string)($before['seo_description'] ?? '') !== $seoDesc ||
                        (string)($before['seo_keywords'] ?? '') !== $seoKeywords ||
                        (string)($before['hashtags'] ?? '') !== $hashtags ||
                        (string)($before['image_alt'] ?? '') !== $imageAlt ||
                        (string)($before['image_caption'] ?? '') !== $imageCaption ||
                        (string)($before['og_title'] ?? '') !== $ogTitle ||
                        (string)($before['og_description'] ?? '') !== $ogDescription ||
                        (string)($before['status'] ?? '') !== $translationStatus ||
                        (string)($before['review_state'] ?? '') !== $reviewState;
                    if ($changed) {
                        if ((string)($before['slug'] ?? '') !== $slug && (string)($before['slug'] ?? '') !== '') {
                            $oldPath=parse_url(locale_url($locale,'article/'.(string)$before['slug']),PHP_URL_PATH)?:'/';
                            $newPath=parse_url(locale_url($locale,'article/'.$slug),PHP_URL_PATH)?:'/';
                            try { Database::exec('INSERT INTO redirects(source_path,target_url,http_code) VALUES(?,?,301) ON DUPLICATE KEY UPDATE target_url=VALUES(target_url),http_code=301',[$oldPath,$newPath]); } catch (\Throwable) {}
                        }
                        if (($before['title'] ?? '') !== $title || ($before['content'] ?? '') !== $clean) {
                            Database::insert('INSERT INTO article_revisions(article_id,user_id,locale,title,excerpt,content,seo_title,seo_description,seo_keywords,hashtags,featured_image,category_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',[$id,$u['id'],$locale,$before['title'] ?? '',$before['excerpt'] ?? '',$before['content'] ?? '',$before['seo_title'] ?? '',$before['seo_description'] ?? '',$before['seo_keywords'] ?? '',$before['hashtags'] ?? '',$article['featured_image'] ?? '',$article['category_id'] ?? null]);
                        }
                        Database::exec(
                            'UPDATE article_translations SET title=?,slug=?,excerpt=?,content=?,seo_title=?,seo_description=?,seo_keywords=?,hashtags=?,image_alt=?,image_caption=?,og_title=?,og_description=?,status=?,review_state=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',
                            [$title,$slug,$excerpt,$clean,$seoTitle,$seoDesc,$seoKeywords,$hashtags,$imageAlt,$imageCaption,$ogTitle,$ogDescription,$translationStatus,$reviewState,$existing['id']]
                        );
                    }
                } else {
                    Database::insert(
                        'INSERT INTO article_translations(article_id,locale,title,slug,excerpt,content,seo_title,seo_description,seo_keywords,hashtags,image_alt,image_caption,og_title,og_description,status,review_state) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                        [$id,$locale,$title,$slug,$excerpt,$clean,$seoTitle,$seoDesc,$seoKeywords,$hashtags,$imageAlt,$imageCaption,$ogTitle,$ogDescription,$translationStatus,$reviewState]
                    );
                }
            }
        });

        if ($submit && !is_editor()) {
            try {
                $editors = Database::all("SELECT id FROM users WHERE role IN ('admin','editor') AND status='active'");
                foreach ($editors as $ed) {
                    Database::insert(
                        "INSERT INTO notifications(user_id,type,title,message,link) VALUES(?,?,?,?,?)",
                        [(int)$ed['id'],'article_review','مقال جديد بانتظار المراجعة','أرسل الكاتب مقالًا للمراجعة.','/writer/articles/'.$id]
                    );
                }
            } catch (\Throwable) {}
        }

        audit_log($submit?'article_submit':'article_save','article',$id,$status);
        if ($translationIssues) {
            $codes=implode('، ',array_values(array_unique($translationIssues)));
            flash('error', "لم تُنشر ترجمات {$codes}: يلزم عنوان وSlug ومحتوى غير فارغ قبل النشر.");
        } else {
            flash('success', $submit ? ($status==='published' ? 'تم نشر المقال والترجمات المكتملة المعتمدة.' : 'تم إرسال المقال للمراجعة ولن يظهر للزوار قبل موافقة الإدارة.') : 'تم حفظ التعديلات.');
        }
        redirect('/writer/articles/'.$id);
    }

    public function account(): void {
        $u = $this->guard();
        $profile = Database::one('SELECT * FROM writer_profiles WHERE user_id=?', [$u['id']]) ?: [];
        $profileTranslations=[];
        try{
            foreach(Database::all('SELECT * FROM writer_profile_translations WHERE user_id=?',[$u['id']]) as $row) $profileTranslations[(string)$row['locale']]=$row;
        }catch(\Throwable){}
        View::render('writer/account', compact('u','profile','profileTranslations') + ['title'=>'ملفي المهني والسيرة الذاتية'], 'dashboard');
    }

    public function saveProfile(): void {
        $u=$this->guard(); Csrf::enforce();
        $requestedUsername=normalize_writer_username((string)($_POST['username']??$u['username']));
        if(!valid_writer_username($requestedUsername)){
            flash('error','اسم المستخدم يجب أن يبدأ بحرف إنجليزي، من 3 إلى 30 محرفًا، ويسمح بالأحرف الإنجليزية والأرقام و - و _ فقط.');
            redirect('/writer/account');
        }
        $taken=Database::one('SELECT id FROM users WHERE username=? AND id<>? LIMIT 1',[$requestedUsername,$u['id']]);
        $oldAlias=null; try{$oldAlias=Database::one('SELECT user_id FROM writer_username_redirects WHERE old_username=? AND user_id<>? LIMIT 1',[$requestedUsername,$u['id']]);}catch(\Throwable){}
        if($taken||$oldAlias){ flash('error','اسم المستخدم محجوز. اختر اسمًا آخر.'); redirect('/writer/account'); }
        if($requestedUsername!==$u['username']){
            try{ Database::insert('INSERT IGNORE INTO writer_username_redirects(user_id,old_username) VALUES(?,?)',[$u['id'],$u['username']]); }catch(\Throwable){}
            Database::exec('UPDATE users SET username=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',[$requestedUsername,$u['id']]);
            $u['username']=$requestedUsername;
        }
        $cleanUrl=static function(string $v): string { $v=trim($v); return ($v==='' || filter_var($v,FILTER_VALIDATE_URL))?$v:''; };
        $jsonList=static function(string $v): string { $lines=preg_split('/\R/u',trim($v))?:[]; $lines=array_values(array_filter(array_map('trim',$lines),static fn($x)=>$x!=='')); return json_encode(array_slice($lines,0,60),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); };
        $title=mb_substr(trim((string)($_POST['professional_title']??'')),0,190);
        $summary=mb_substr(trim((string)($_POST['cv_summary']??'')),0,5000);
        $location=mb_substr(trim((string)($_POST['location']??'')),0,190);
        $website=$cleanUrl((string)($_POST['website']??'')); $linkedin=$cleanUrl((string)($_POST['linkedin']??'')); $portfolioUrl=$cleanUrl((string)($_POST['portfolio_url']??''));
        $contact=trim((string)($_POST['contact_email']??'')); if($contact!=='' && !filter_var($contact,FILTER_VALIDATE_EMAIL)) $contact='';
        $fields=['experience','education','skills','certificates','languages','achievements','portfolio']; $data=[]; foreach($fields as $x)$data[$x]=$jsonList((string)($_POST[$x]??''));
        Database::exec("INSERT INTO writer_profiles(user_id,professional_title,cv_summary,location,website,linkedin,portfolio_url,contact_email,experience_json,education_json,skills_json,certificates_json,languages_json,achievements_json,portfolio_json,is_public,show_contact) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE professional_title=VALUES(professional_title),cv_summary=VALUES(cv_summary),location=VALUES(location),website=VALUES(website),linkedin=VALUES(linkedin),portfolio_url=VALUES(portfolio_url),contact_email=VALUES(contact_email),experience_json=VALUES(experience_json),education_json=VALUES(education_json),skills_json=VALUES(skills_json),certificates_json=VALUES(certificates_json),languages_json=VALUES(languages_json),achievements_json=VALUES(achievements_json),portfolio_json=VALUES(portfolio_json),is_public=VALUES(is_public),show_contact=VALUES(show_contact)",[$u['id'],$title,$summary,$location,$website,$linkedin,$portfolioUrl,$contact,$data['experience'],$data['education'],$data['skills'],$data['certificates'],$data['languages'],$data['achievements'],$data['portfolio'],isset($_POST['is_public'])?1:0,isset($_POST['show_contact'])?1:0]);
        Database::exec('UPDATE users SET bio=? WHERE id=?',[mb_substr($summary,0,1200),$u['id']]);
        Database::exec("INSERT INTO writer_profile_translations(user_id,locale,display_name,bio,professional_title,cv_summary,status) VALUES(?,?,?,?,?,?, 'published') ON DUPLICATE KEY UPDATE display_name=VALUES(display_name),bio=VALUES(bio),professional_title=VALUES(professional_title),cv_summary=VALUES(cv_summary),status='published'",[$u['id'],'ar',$u['name'],mb_substr($summary,0,1200),$title,$summary]);
        $translations=is_array($_POST['profile_translation']??null)?$_POST['profile_translation']:[];
        foreach(all_locales() as $code=>$info){
            if($code==='ar'||!isset($translations[$code])||!is_array($translations[$code])) continue;
            $row=$translations[$code];
            $displayName=mb_substr(trim((string)($row['display_name']??'')),0,190);
            $bio=mb_substr(trim((string)($row['bio']??'')),0,1200);
            $translatedTitle=mb_substr(trim((string)($row['professional_title']??'')),0,190);
            $translatedSummary=mb_substr(trim((string)($row['cv_summary']??'')),0,5000);
            if($displayName===''&&$bio===''&&$translatedTitle===''&&$translatedSummary==='') continue;
            $requestedStatus=(string)($row['status']??'review');
            $translationStatus=is_editor()&&in_array($requestedStatus,['draft','review','published'],true)?$requestedStatus:'review';
            Database::exec("INSERT INTO writer_profile_translations(user_id,locale,display_name,bio,professional_title,cv_summary,status) VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE display_name=VALUES(display_name),bio=VALUES(bio),professional_title=VALUES(professional_title),cv_summary=VALUES(cv_summary),status=VALUES(status)",[$u['id'],$code,$displayName,$bio,$translatedTitle,$translatedSummary,$translationStatus]);
        }
        audit_log('writer_profile_update','user',(int)$u['id'],'professional profile'); flash('success','تم حفظ ملفك المهني والسيرة الذاتية.'); redirect('/writer/account');
    }

    public function checkUsername(): void {
        $u=$this->guard();
        header('Content-Type: application/json; charset=utf-8');
        $username=normalize_writer_username((string)($_GET['username']??''));
        if(!valid_writer_username($username)){ echo json_encode(['ok'=>false,'available'=>false,'username'=>$username,'message'=>'استخدم 3–30 محرفًا إنجليزيًا، وابدأ بحرف.'],JSON_UNESCAPED_UNICODE); return; }
        $taken=Database::one('SELECT id FROM users WHERE username=? AND id<>? LIMIT 1',[$username,$u['id']]); $alias=null; try{$alias=Database::one('SELECT user_id FROM writer_username_redirects WHERE old_username=? AND user_id<>? LIMIT 1',[$username,$u['id']]);}catch(\Throwable){} $busy=(bool)($taken||$alias);
        echo json_encode(['ok'=>true,'available'=>!$busy,'username'=>$username,'message'=>$busy?'اسم المستخدم محجوز':'اسم المستخدم متاح'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    }

    public function shareCenter(): void { redirect('/writer/card',301); }

    public function uploadAvatar(): void { $u=$this->guard(); Csrf::enforce(); try{$path=Upload::image($_FILES['avatar']??[]);if(!$path)throw new \RuntimeException('اختر صورة أولًا.');Database::exec('UPDATE users SET avatar=? WHERE id=?',[$path,$u['id']]);flash('success','تم تحديث صورتك الشخصية.');}catch(\Throwable $e){flash('error',$e->getMessage());}redirect('/writer/account'); }

    public function changePassword(): void {
        $u = $this->guard();
        Csrf::enforce();
        $current = (string)($_POST['current_password'] ?? '');
        $new = (string)($_POST['new_password'] ?? '');
        $confirm = (string)($_POST['new_password_confirmation'] ?? '');
        $row = Database::one('SELECT password_hash FROM users WHERE id=?', [$u['id']]);
        if (!$row || !password_verify($current, $row['password_hash'])) {
            flash('error','كلمة المرور الحالية غير صحيحة.');
            redirect('/writer/account');
        }
        if (mb_strlen($new) < 12 || $new !== $confirm) {
            flash('error','كلمة المرور الجديدة يجب أن تكون 12 محرفًا على الأقل ومتطابقة في الحقلين.');
            redirect('/writer/account');
        }
        $algo = in_array('argon2id', password_algos(), true) ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
        Database::exec('UPDATE users SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE id=?', [password_hash($new,$algo),$u['id']]);
        flash('success','تم تغيير كلمة المرور بنجاح.');
        redirect('/writer/account');
    }

    public function readNotification(): void {
        $u = $this->guard();
        Csrf::enforce();
        $id = (int)($_POST['id'] ?? 0);
        try { Database::exec('UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?', [$id,$u['id']]); } catch (\Throwable) {}
        redirect('/writer');
    }
}
