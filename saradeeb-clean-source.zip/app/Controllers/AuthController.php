<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\View;

final class AuthController {
    public function loginForm(string $locale='ar'): void {
        if(!valid_locale($locale)) $locale=default_locale();
        View::render('auth/login',compact('locale')+['title'=>tr('login',$locale)],'public');
    }

    public function login(string $locale='ar'): void {
        Csrf::enforce();
        $email=trim((string)($_POST['email']??''));
        $pass=(string)($_POST['password']??'');
        if(Auth::attempt($email,$pass)){
            clear_old();
            if(Auth::twoFactorPending()) redirect('/two-factor');
            $u=Auth::user();
            if(in_array($u['role'],['admin','editor'],true)) redirect('/admin');
            if(in_array($u['role'],['writer','trusted_writer'],true)) redirect('/writer');
            redirect(locale_url($locale,'community'));
        }
        set_old(['email'=>$email]);
        flash('error',auth_ui($locale)['invalid_login']);
        redirect(locale_url($locale,'login'));
    }

    public function registerForm(string $locale='ar'): void {
        if(!valid_locale($locale)) $locale=default_locale();
        View::render('auth/member-register',compact('locale')+['title'=>auth_ui($locale)['register_title']],'public');
    }

    public function register(string $locale='ar'): void {
        Csrf::enforce();
        if(!valid_locale($locale)) $locale=default_locale();
        $A=auth_ui($locale);
        $ip=(string)($_SERVER['REMOTE_ADDR']??'unknown');
        $key=hash('sha256','community_register|'.$ip);
        if(setting('security_login_throttle','1')==='1') try {
            $th=Database::one('SELECT attempts,last_attempt_at,locked_until FROM auth_throttles WHERE throttle_key=?',[$key]);
            if($th && !empty($th['locked_until']) && strtotime((string)$th['locked_until'])>time()){
                flash('error',$A['register_blocked']);
                redirect(locale_url($locale,'register'));
            }
            $attempts=($th && strtotime((string)$th['last_attempt_at'])>time()-3600)?(int)$th['attempts']:0;
            $attempts++;
            $locked=$attempts>=5?date('Y-m-d H:i:s',time()+3600):null;
            Database::exec("INSERT INTO auth_throttles(throttle_key,attempts,last_attempt_at,locked_until) VALUES(?,?,CURRENT_TIMESTAMP,?) ON DUPLICATE KEY UPDATE attempts=VALUES(attempts),last_attempt_at=CURRENT_TIMESTAMP,locked_until=VALUES(locked_until)",[$key,$attempts,$locked]);
        } catch (\Throwable) {}

        $name=trim((string)($_POST['name']??''));
        $username=slugify((string)($_POST['username']??''));
        $email=mb_strtolower(trim((string)($_POST['email']??'')));
        set_old(['name'=>$name,'username'=>$username,'email'=>$email]);
        if(mb_strlen($name)<2 || mb_strlen($username)<3 || !filter_var($email,FILTER_VALIDATE_EMAIL)){
            flash('error',$A['invalid_register']);
            redirect(locale_url($locale,'register'));
        }
        if(Database::one('SELECT id FROM users WHERE email=? OR username=? LIMIT 1',[$email,$username])){
            flash('error',$A['account_exists']);
            redirect(locale_url($locale,'register'));
        }
        $token=bin2hex(random_bytes(32));
        $algo=in_array('argon2id',password_algos(),true)?PASSWORD_ARGON2ID:PASSWORD_DEFAULT;
        $random=password_hash(bin2hex(random_bytes(24)),$algo);
        Database::insert("INSERT INTO users(name,username,email,password_hash,role,status,activation_token_hash,activation_expires_at) VALUES(?,?,?,?,'member','pending',?,?)",[$name,$username,$email,$random,hash('sha256',$token),date('Y-m-d H:i:s',time()+86400)]);
        $link=locale_url($locale,'activate').'?token='.rawurlencode($token);
        $sent=send_site_mail($email,'فعّل حسابك في سراديب',"مرحبًا {$name}،\n\nفعّل بريدك وأنشئ كلمة المرور من الرابط التالي خلال 24 ساعة:\n{$link}\n\nإذا لم تنشئ هذا الحساب فتجاهل الرسالة.");
        clear_old();
        flash('success',$A['register_ok'].((!$sent&&config('debug',false))?' Local preview: '.$link:''));
        redirect(locale_url($locale,'login'));
    }

    public function applicationForm(string $locale='ar'): void {
        if(!valid_locale($locale)) $locale=default_locale();
        View::render('auth/register',compact('locale')+['title'=>auth_ui($locale)['writer_title']],'public');
    }

    public function submitApplication(string $locale='ar'): void {
        Csrf::enforce();
        if(!valid_locale($locale)) $locale=default_locale();
        $A=auth_ui($locale);
        $name=trim((string)($_POST['name']??''));
        $email=mb_strtolower(trim((string)($_POST['email']??'')));
        $phone=trim((string)($_POST['phone']??''));
        $country=trim((string)($_POST['country']??''));
        $city=trim((string)($_POST['city']??''));
        $topics=trim((string)($_POST['topics']??''));
        $experience=trim((string)($_POST['experience']??''));
        $sampleUrl=trim((string)($_POST['sample_url']??''));
        $bio=trim((string)($_POST['bio']??''));
        set_old($_POST);

        if(mb_strlen($name)<2 || !filter_var($email,FILTER_VALIDATE_EMAIL) || mb_strlen($phone)<7 || mb_strlen($bio)<30){
            flash('error',$A['invalid_application']);
            redirect(locale_url($locale,'writer-application'));
        }
        $verifyToken=bin2hex(random_bytes(32));
        Database::insert(
            "INSERT INTO writer_applications(name,email,phone,country,city,topics,experience,sample_url,bio,status,verification_token_hash,verification_expires_at,email_verified_at) VALUES(?,?,?,?,?,?,?,?,?,'new',?,?,NULL)",
            [$name,$email,$phone,$country,$city,$topics,$experience,$sampleUrl,$bio,hash('sha256',$verifyToken),date('Y-m-d H:i:s',time()+86400)]
        );
        $verifyLink=locale_url($locale,'verify-writer-application').'?token='.rawurlencode($verifyToken);
        $sent=send_site_mail($email,'تأكيد بريد طلب الانضمام إلى سراديب',"مرحبًا {$name}،

لتأكيد بريدك وإرسال طلبك إلى إدارة سراديب افتح الرابط التالي خلال 24 ساعة:
{$verifyLink}

إذا لم ترسل هذا الطلب فتجاهل الرسالة.");
        clear_old();
        flash('success',$A['application_ok'].((!$sent&&config('debug',false))?' Local preview: '.$verifyLink:''));
        redirect(locale_url($locale,'writer-application'));
    }


    public function verifyWriterApplication(string $locale='ar'): void {
        if(!valid_locale($locale)) $locale=default_locale();
        $A=auth_ui($locale);
        $token=(string)($_GET['token']??'');
        if($token===''||strlen($token)<32){ flash('error',$A['invalid_link']); redirect(locale_url($locale,'writer-application')); }
        $app=Database::one('SELECT * FROM writer_applications WHERE verification_token_hash=? AND verification_expires_at>CURRENT_TIMESTAMP LIMIT 1',[hash('sha256',$token)]);
        if(!$app){ flash('error',$A['expired_link']); redirect(locale_url($locale,'writer-application')); }
        Database::exec('UPDATE writer_applications SET email_verified_at=CURRENT_TIMESTAMP,verification_token_hash=NULL,verification_expires_at=NULL WHERE id=?',[$app['id']]);
        $target=setting('writer_application_email',setting('contact_email',''));
        if(setting('mail_notifications','0')==='1' && filter_var($target,FILTER_VALIDATE_EMAIL)){
            $body="طلب كاتب مؤكد البريد في سراديب\n\nالاسم: {$app['name']}\nالبريد: {$app['email']}\nالهاتف: {$app['phone']}\nالدولة: {$app['country']}\nالمدينة: {$app['city']}\nالمواضيع: {$app['topics']}\nالخبرة: {$app['experience']}\nنموذج كتابة: {$app['sample_url']}\n\nالنبذة:\n{$app['bio']}\n";
            send_site_mail($target,'طلب انضمام كاتب مؤكد - سراديب',$body);
        }
        flash('success',$A['application_verified']);
        redirect(locale_url($locale,'writer-application'));
    }

    public function twoFactorForm(): void {
        $pending=Auth::pendingTwoFactorUser(); if(!$pending) redirect('/login');
        View::render('auth/two-factor',['pending'=>$pending,'locale'=>default_locale(),'title'=>'التحقق بخطوتين'],'public');
    }
    public function twoFactor(): void {
        Csrf::enforce(); $u=Auth::pendingTwoFactorUser(); if(!$u) redirect('/login');
        $code=trim((string)($_POST['code']??'')); $ok=totp_verify((string)$u['two_factor_secret'],$code);
        if(!$ok){
            $codes=json_decode((string)($u['two_factor_recovery_codes']??'[]'),true)?:[];
            $needle=hash('sha256',strtoupper(str_replace([' ','-'],'',$code))); $idx=array_search($needle,$codes,true);
            if($idx!==false){ unset($codes[$idx]); Database::exec('UPDATE users SET two_factor_recovery_codes=? WHERE id=?',[json_encode(array_values($codes)),(int)$u['id']]); $ok=true; }
        }
        if(!$ok){ flash('error','رمز التحقق غير صحيح.'); redirect('/two-factor'); }
        Auth::completeTwoFactor(); audit_log('two_factor_login','user',(int)$u['id'],''); redirect('/admin');
    }

    public function activationForm(string $locale='ar'): void {
        if(!valid_locale($locale)) $locale=default_locale();
        $token=(string)($_GET['token']??'');
        $valid=$this->tokenUser($token,'activation_token_hash','activation_expires_at');
        View::render('auth/activate',compact('locale','token','valid')+['title'=>'تفعيل حساب سراديب'],'public');
    }

    public function activate(string $locale='ar'): void {
        Csrf::enforce();
        if(!valid_locale($locale)) $locale=default_locale();
        $token=(string)($_POST['token']??'');
        $u=$this->tokenUser($token,'activation_token_hash','activation_expires_at');
        $password=(string)($_POST['password']??'');
        $confirm=(string)($_POST['password_confirmation']??'');
        if(!$u){ flash('error','رابط التفعيل غير صالح أو انتهت صلاحيته.'); redirect(locale_url($locale,'activate').'?token='.rawurlencode($token)); }
        if(mb_strlen($password)<12 || $password!==$confirm){ flash('error','اكتب كلمة مرور من 12 محرفًا على الأقل وتأكد من تطابقها.'); redirect(locale_url($locale,'activate').'?token='.rawurlencode($token)); }
        $algo=in_array('argon2id',password_algos(),true)?PASSWORD_ARGON2ID:PASSWORD_DEFAULT;
        Database::exec(
            'UPDATE users SET password_hash=?,status=\'active\',email_verified_at=CURRENT_TIMESTAMP,activation_token_hash=NULL,activation_expires_at=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?',
            [password_hash($password,$algo),$u['id']]
        );
        flash('success','تم تأكيد بريدك وإنشاء كلمة المرور. يمكنك تسجيل الدخول الآن.');
        redirect(locale_url($locale,'login'));
    }

    public function forgotForm(string $locale='ar'): void {
        if(!valid_locale($locale)) $locale=default_locale();
        View::render('auth/forgot',compact('locale')+['title'=>auth_ui($locale)['forgot_title']],'public');
    }

    public function forgot(string $locale='ar'): void {
        Csrf::enforce();
        if(!valid_locale($locale)) $locale=default_locale();
        $A=auth_ui($locale);
        $email=mb_strtolower(trim((string)($_POST['email']??'')));
        $u=filter_var($email,FILTER_VALIDATE_EMAIL)?Database::one('SELECT id,name,email FROM users WHERE email=? AND status<>\'blocked\' LIMIT 1',[$email]):null;
        $debugLink='';
        if($u){
            $token=bin2hex(random_bytes(32));
            Database::exec('UPDATE users SET password_reset_token_hash=?,password_reset_expires_at=? WHERE id=?',[hash('sha256',$token),date('Y-m-d H:i:s',time()+3600),$u['id']]);
            $link=locale_url($locale,'reset-password').'?token='.rawurlencode($token);
            $sent=send_site_mail($u['email'],'استعادة كلمة مرور سراديب',"مرحبًا {$u['name']}،\n\nاستخدم الرابط التالي خلال ساعة واحدة لإنشاء كلمة مرور جديدة:\n$link\n\nإذا لم تطلب ذلك فتجاهل الرسالة.");
            if(!$sent && config('debug',false)) $debugLink=$link;
        }
        $message=$A['forgot_ok'];
        if($debugLink!=='') $message.=' Local preview: '.$debugLink;
        flash('success',$message);
        redirect(locale_url($locale,'forgot-password'));
    }

    public function resetForm(string $locale='ar'): void {
        if(!valid_locale($locale)) $locale=default_locale();
        $token=(string)($_GET['token']??'');
        $valid=$this->tokenUser($token,'password_reset_token_hash','password_reset_expires_at');
        View::render('auth/reset',compact('locale','token','valid')+['title'=>auth_ui($locale)['reset_title']],'public');
    }

    public function reset(string $locale='ar'): void {
        Csrf::enforce();
        if(!valid_locale($locale)) $locale=default_locale();
        $token=(string)($_POST['token']??'');
        $u=$this->tokenUser($token,'password_reset_token_hash','password_reset_expires_at');
        $password=(string)($_POST['password']??'');
        $confirm=(string)($_POST['password_confirmation']??'');
        if(!$u){ flash('error','الرابط غير صالح أو انتهت صلاحيته.'); redirect(locale_url($locale,'forgot-password')); }
        if(mb_strlen($password)<12 || $password!==$confirm){ flash('error','كلمة المرور يجب أن تكون 12 محرفًا على الأقل ومتطابقة.'); redirect(locale_url($locale,'reset-password').'?token='.rawurlencode($token)); }
        $algo=in_array('argon2id',password_algos(),true)?PASSWORD_ARGON2ID:PASSWORD_DEFAULT;
        Database::exec('UPDATE users SET password_hash=?,password_reset_token_hash=NULL,password_reset_expires_at=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?',[password_hash($password,$algo),$u['id']]);
        flash('success','تم تغيير كلمة المرور.');
        redirect(locale_url($locale,'login'));
    }

    private function tokenUser(string $token,string $column,string $expiry): ?array {
        if($token==='' || strlen($token)<32) return null;
        $allowed=['activation_token_hash'=>'activation_expires_at','password_reset_token_hash'=>'password_reset_expires_at'];
        if(!isset($allowed[$column]) || $allowed[$column]!==$expiry) return null;
        return Database::one("SELECT id,name,email,role FROM users WHERE {$column}=? AND {$expiry}>CURRENT_TIMESTAMP LIMIT 1",[hash('sha256',$token)]);
    }

    public function stopImpersonation(): void {
        Csrf::enforce();
        if(!Auth::isImpersonating()) redirect('/');
        $adminId=Auth::impersonatorId();
        if(Auth::stopImpersonation()){
            audit_log('admin_impersonate_stop','user',$adminId,'Returned to admin account');
            flash('success','تمت العودة إلى حساب الإدارة.');
            redirect('/admin');
        }
        redirect('/');
    }

    public function logout(): void {
        Csrf::enforce(); Auth::logout(); redirect('/');
    }
}
