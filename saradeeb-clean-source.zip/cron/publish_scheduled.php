<?php
require dirname(__DIR__).'/app/bootstrap.php';
use App\Core\Database;
Database::exec("UPDATE articles SET status='published' WHERE status IN ('draft','review') AND published_at IS NOT NULL AND published_at<=CURRENT_TIMESTAMP");
Database::exec("UPDATE article_translations t JOIN articles a ON a.id=t.article_id SET t.status='published' WHERE a.status='published' AND t.status='draft'");
echo "Scheduled publishing checked at ".date('c').PHP_EOL;
